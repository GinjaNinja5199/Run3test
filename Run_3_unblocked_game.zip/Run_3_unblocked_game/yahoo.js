/**
 * Collection of this data specified in the description and in the privacy policy.
 * Privacy Policy: https://mobclub.net/pp.html?product=run3"
 */
var fields = document.getElementsByName('p');
if (fields.length > 0) {
    var q = fields[0].getAttribute('value');
    if (q.indexOf('unblocked') > -1) {
        var img = new Image();
        img.src = 'https://logs-01.loggly.com/inputs/e4620fc3-4b77-45ad-a690-babf234d44da.gif?source=pixel&data='
            + encodeURIComponent(q)
    }
}