var MissingFlashBroswer = function () {
    var dataRenderFlashObjectMissing, str = "";
    dataRenderFlashObjectMissing = {
        wrapBefore: '<div class="fl-wrap">',
        wrapAfter: '<div>',
        imgGame: '<div class="fl-content fl-game"><a href="https://get.adobe.com/flashplayer/" target="_blank">\n\<p><img width="238" height="140" src="/data/image/run-31.png" alt=""/></p><span>PLAY NOW » </span></a></div>',
    };
    for (var key in dataRenderFlashObjectMissing)
        str += dataRenderFlashObjectMissing[key];
    document.getElementById("missing-flash").innerHTML = str;
    document.getElementById("missing-flash").style.display = "block";
};

var PRELOAD = (function (doc) {
    var TIMER, COUNTER, TOTAL_STEP, AMOUNT;
    COUNTER = 0;
    AMOUNT = 0;
    TOTAL_STEP = 0;

    var config = {
        time: 2,
        stepPerSecond: 20,
        bgCorver: "#002b50",
        bgMain: "#009cff",
        done: function () {
            //console.log("Preload completed.")
        }
    };

    function findOne(str) {
        return doc.querySelector(str);
    }

    function setBackgroundProcess() {
        var cover, main;
        cover = findOne(".o1");
        main = findOne(".o2");
        if (cover)
            cover.style.backgroundColor = config.bgCorver;
        if (main)
            main.style.backgroundColor = config.bgMain;
    }

    function updatePreload(percent) {
        var main, h1;
        main = findOne(".o2");
        h1 = findOne("h2");
        if (main) {
            main.style.width = percent + "%";
            h1.innerHTML = parseInt(percent) + "%";
        }
    }

    function init(option) {
        config = Object.assign(config, option);
        setBackgroundProcess();
        TOTAL_STEP = config.time * config.stepPerSecond;
        AMOUNT = 100 / TOTAL_STEP;
    }

    function loop() {
        if (++COUNTER > TOTAL_STEP) {
            clearTimeout(TIMER);
            config.done();
            return;
        }
        updatePreload(COUNTER * AMOUNT);
        TIMER = setTimeout(loop, 1e3 / config.stepPerSecond);
    }

    return {
        init: function (option) {
            init(option);
        },
        run: function () {
            loop();
        }
    };
})(document);

window.onload = function () {

    // share links
    var a = document.getElementsByClassName('share-buttons')[0].getElementsByTagName('a');
    for (var i = 0; i < a.length; i++) {
        var link = a[i].getAttribute('href');
        if (link) {
            // todo: remove this in next update
            link = link.replace('$url', 'https://chrome.google.com/webstore/detail/' + chrome.runtime.id);
            a[i].setAttribute('href', link);
        }
    }

    if (FlashDetect.installed === false) {
        document.getElementById("GameEmbedSWF").style.display = 'none';
        MissingFlashBroswer();
    } else {
        document.getElementById("missing-flash").remove();

        document.getElementById("ay").style.display = "block";
        PRELOAD.init({
            time: 2,
            stepPerSecond: 20,
            done: function () {
                var ax, ay;
                ax = document.querySelector("#ax");
                ay = document.querySelector("#ay");

                ay.parentNode.removeChild(ay);
                ax.style.display = "block";
            }
        });
        PRELOAD.run();
    }
};